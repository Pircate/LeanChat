//
//  SCNavigationController.h
//
//  Created by Singro on 2/19/14.
//  Copyright (c) 2014 Singro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCNavigationController : UINavigationController

@property (nonatomic, assign) BOOL enableInnerInactiveGesture;

@end
