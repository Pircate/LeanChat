//
//  SCNavigationPopAnimation.h
//
//  Created by Singro on 3/2/14.
//  Copyright (c) 2014 Singro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCNavigationPopAnimation : NSObject <UIViewControllerAnimatedTransitioning>

@end
