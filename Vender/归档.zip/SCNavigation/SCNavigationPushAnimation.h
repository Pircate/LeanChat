//
//  SCNavigationPushAnimation.h
//
//  Created by Singro on 5/25/14.
//  Copyright (c) 2014 Singro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SCNavigationPushAnimation : NSObject <UIViewControllerAnimatedTransitioning>

@end
